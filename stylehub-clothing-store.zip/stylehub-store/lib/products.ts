import { collection, getDocs, limit, query, where } from 'firebase/firestore';
import { db } from './firebase';
import { adminDb } from './firebase-admin';

export type Product = { id: string; slug: string; name: string; description: string; price: number; compareAtPrice?: number; image: string; images?: string[]; category: string; sizes: string[]; colors: string[]; stock: number; active: boolean; updatedAt?: string; brand?: string };
const demo: Product[] = [
 {id:'classic-cotton-shirt',slug:'classic-cotton-shirt',name:'Classic Cotton Shirt',description:'A breathable cotton shirt with a refined fit. Designed for everyday wear, easy layering and effortless style.',price:1499,compareAtPrice:1999,image:'https://images.unsplash.com/photo-1603252109303-2751441dd157?auto=format&fit=crop&w=900&q=85',category:'Men',sizes:['S','M','L','XL','XXL'],colors:['Navy','White','Black'],stock:42,active:true,brand:'StyleHub'},
 {id:'linen-blend-blazer',slug:'linen-blend-blazer',name:'Linen Blend Blazer',description:'A lightweight tailored blazer with a relaxed modern silhouette for smart occasions.',price:3499,compareAtPrice:4299,image:'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=900&q=85',category:'Women',sizes:['XS','S','M','L','XL'],colors:['Sand','Black'],stock:18,active:true,brand:'StyleHub'},
 {id:'everyday-denim',slug:'everyday-denim',name:'Everyday Straight Denim',description:'Comfortable straight-leg denim made for repeat wear and easy styling.',price:2199,image:'https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=900&q=85',category:'Denim',sizes:['28','30','32','34','36'],colors:['Blue','Black'],stock:27,active:true,brand:'StyleHub'},
 {id:'soft-knit-polo',slug:'soft-knit-polo',name:'Soft Knit Polo',description:'A soft knit polo that balances understated polish with all-day comfort.',price:1799,image:'https://images.unsplash.com/photo-1625910513413-5fc45e7d1a6b?auto=format&fit=crop&w=900&q=85',category:'Men',sizes:['S','M','L','XL'],colors:['Cream','Olive','Navy'],stock:31,active:true,brand:'StyleHub'},
];
export async function getProducts(): Promise<Product[]> {
 try { if (db) { const snap = await getDocs(query(collection(db,'products'),where('active','==',true),limit(60))); if (!snap.empty) return snap.docs.map(d=>({id:d.id,...d.data()} as Product)); } } catch (e) { console.warn('Client product query fallback:', e); }
 return demo;
}
export async function getPublishedProductsServer(): Promise<Product[]> {
 try { const snap = await adminDb().collection('products').where('active','==',true).limit(5000).get(); if (!snap.empty) return snap.docs.map(d=>({id:d.id,...d.data()} as Product)); } catch (e) { console.warn('Using demo product data; server Firebase Admin may not be configured.'); }
 return demo;
}
export async function getProductBySlug(slug: string): Promise<Product | null> {
 const list = await getPublishedProductsServer(); return list.find(p=>p.slug===slug && p.active) ?? null;
}

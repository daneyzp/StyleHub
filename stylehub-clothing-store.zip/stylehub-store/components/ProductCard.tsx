import Link from 'next/link';
import type { Product } from '@/lib/products';
import { inr } from '@/lib/money';
export default function ProductCard({product}:{product:Product}){return <article className="productCard"><Link className="productImage" href={`/products/${product.slug}`}><img src={product.image} alt={product.name} loading="lazy"/><span className="quickTag">{product.stock>0?'In stock':'Sold out'}</span></Link><div className="productMeta"><div><p className="eyebrow">{product.category}</p><Link href={`/products/${product.slug}`} className="productName">{product.name}</Link></div><strong>{inr(product.price)}</strong></div><p className="muted">{product.colors.slice(0,3).join(' · ')}</p></article>}

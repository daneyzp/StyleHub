'use client';
import { useEffect,useState } from 'react';
import { useRouter } from 'next/navigation';
import { onAuthStateChanged } from 'firebase/auth';
import { doc,getDoc } from 'firebase/firestore';
import { auth,db } from '@/lib/firebase';
export default function PortalGuard({role,children}:{role:string;children:React.ReactNode}){const [state,setState]=useState<'loading'|'allowed'|'denied'>('loading');const router=useRouter();useEffect(()=>{if(!auth||!db){setState('denied');return;}return onAuthStateChanged(auth,async user=>{if(!user){setState('denied');router.replace('/login');return;}try{const snap=await getDoc(doc(db,'users',user.uid));if(snap.exists()&&snap.data().role===role&&snap.data().active!==false)setState('allowed');else setState('denied');}catch{setState('denied')}})},[role,router]);if(state==='loading')return <main className="page"><p>Checking portal access…</p></main>;if(state!=='allowed')return <main className="page"><h1>Access restricted</h1><p className="pageLead">This portal is only available to an authorized {role} account.</p><a className="button" href="/account">Go to account</a></main>;return <>{children}</>}

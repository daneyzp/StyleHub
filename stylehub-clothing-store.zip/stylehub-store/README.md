# StyleHub — Premium clothing store (Next.js + Firebase)

A starter implementation for a clothing e-commerce shop for India with customer pages, four role portals, server-rendered product pages, product JSON-LD, dynamic sitemap and robots.txt, Firebase Auth/Firestore/Storage, and a server-verified checkout foundation.

## Included routes

- `/` — storefront / index dashboard
- `/login` — email/password login and registration
- `/products/[slug]` — server-rendered, SEO-friendly product details
- `/cart` — client shopping bag
- `/checkout` — address, COD and online payment choice
- `/wishlist` — saved products
- `/account` — customer account entry point
- `/portal/admin`, `/portal/supplier`, `/portal/distributor`, `/portal/sponsor` — portal UI shells
- `/sitemap.xml` — generated from active products
- `/robots.txt` — generated crawler directives
- `/api/checkout` — server-side cart price/stock validation and COD/order creation
- `/api/razorpay/order` and `/api/razorpay/verify` — Razorpay order creation and HMAC signature verification endpoints

## Run locally

1. Install Node.js 20+ and npm.
2. Copy `.env.example` to `.env.local` and fill Firebase web config, Firebase Admin service-account values and `NEXT_PUBLIC_SITE_URL`.
3. In Firebase Console create a project, enable Email/Password under Authentication, create Firestore and Storage, then deploy `firestore.rules` and `storage.rules`.
4. Install and run:

   ```bash
   npm install
   npm run dev
   ```

5. Visit `http://localhost:3000`.

The storefront includes demo product fallback data so the UI renders before Firebase products are added. In production, add products to Firestore `products` documents using fields such as:

```json
{
  "slug": "classic-cotton-shirt",
  "name": "Classic Cotton Shirt",
  "description": "A breathable cotton shirt with a refined fit.",
  "price": 1499,
  "compareAtPrice": 1999,
  "image": "https://...",
  "images": ["https://..."],
  "category": "Men",
  "sizes": ["S", "M", "L", "XL"],
  "colors": ["Navy", "White"],
  "stock": 42,
  "active": true,
  "brand": "StyleHub",
  "updatedAt": "2026-10-10T00:00:00.000Z",
  "supplierId": "supplier-auth-uid"
}
```

Set `active: true` only after reviewing a product. Product document ID is used as the product ID in cart/checkout; use unique, stable slugs. For SEO, each active product needs a distinct, useful title, description, original image and canonical URL.

## Important production work

- **Portal authorization:** portal pages in this starter are UI shells. Add a server layout/middleware that verifies Firebase ID tokens and checks roles from a trusted Firestore user document or custom claims before rendering data or enabling mutations. Never grant roles from client-side registration; create staff roles from a trusted Admin SDK script/Cloud Function and lock role fields from customer writes. Portal server actions/APIs must repeat authorization checks.
- **Stock consistency:** checkout re-reads product price and stock on the server. Before accepting real traffic, reserve/decrement stock in a Firestore transaction, implement idempotency, order cancellation/restock, and abuse/rate limiting. Do not trust client-supplied totals.
- **Online payment:** wire the Razorpay checkout widget on the checkout page: call `/api/razorpay/order` with the created order ID, open Razorpay Checkout using returned `keyId`, then send Razorpay callback values to `/api/razorpay/verify`. Also implement Razorpay webhooks and reconcile payment state server-side. The current checkout deliberately does not claim an online payment is complete without the widget and verification flow. Test with test keys before live keys.
- **Policies:** publish real Privacy, Terms, Shipping, Returns/Refunds and Contact pages before launch.
- **Security:** add App Check, API rate limiting, monitoring, backups, validation, order notifications, GST/tax handling as applicable, and server-side admin authorization. Review rules for your exact workflow before production.
- **Images:** use Firebase Storage or a CDN; for production use `next/image` with approved remote patterns and meaningful alt text.

## Assigning portal roles safely

New registrations are assigned `role: "customer"`. Do not let clients change their own role. Assign `admin`, `supplier`, `distributor` or `sponsor` using a trusted Admin SDK script, protected server operation, or Cloud Function. The Firestore rules depend on `users/{uid}.role` and deny writes to orders from the client.

## Google Search Console: product indexing

1. Deploy the site to a stable public domain and set `NEXT_PUBLIC_SITE_URL` to that exact HTTPS origin (no trailing path). Do not leave `https://yourstore.com` in production.
2. Verify domain ownership in [Google Search Console](https://search.google.com/search-console/) using DNS TXT verification (recommended for a domain property).
3. Open **Sitemaps** and submit `https://yourstore.com/sitemap.xml`. Next.js generates the sitemap dynamically from active product documents. It revalidates hourly; the sitemap includes up to 5,000 active products in this starter. For larger catalogs, split into sitemap index files / batches.
4. Test a product URL in Search Console **URL Inspection** and use **Test Live URL**. Check that it returns HTTP 200, is not blocked by robots/noindex, has the correct canonical URL and contains rendered product content.
5. Validate Product structured data with Google's [Rich Results Test](https://search.google.com/test/rich-results). Product/Offer JSON-LD is emitted on each product page.
6. Keep product pages public. Do not require login for crawling public product information. Cart, checkout, wishlist, account and portals are intentionally disallowed in robots.txt.
7. Use original descriptions and high-quality product images; avoid duplicate/thin pages, out-of-stock broken URLs, and conflicting canonical URLs. Return a real 404 for removed slugs or use 301 redirects when a product slug changes.
8. Monitor Search Console **Pages / Indexing**, **Sitemaps**, and enhancements. Sitemap submission is a discovery hint, not a guarantee that Google will index every product. Indexing may take days or longer and Google decides eligibility.

Official references: [Google product structured data](https://developers.google.com/search/docs/appearance/structured-data/product), [sitemaps](https://developers.google.com/search/docs/crawling-indexing/sitemaps/overview), [robots.txt](https://developers.google.com/search/docs/crawling-indexing/robots/intro), [Firebase](https://firebase.google.com/docs), [Razorpay standard checkout](https://razorpay.com/docs/payments/payment-gateway/web-integration/standard/).

import type { MetadataRoute } from 'next';
import { getPublishedProductsServer } from '@/lib/products';
export const revalidate=3600;
export default async function sitemap():Promise<MetadataRoute.Sitemap>{const base=(process.env.NEXT_PUBLIC_SITE_URL||'https://yourstore.com').replace(/\/$/,'');const products=await getPublishedProductsServer();return [{url:base,lastModified:new Date(),changeFrequency:'daily',priority:1},{url:`${base}/login`,changeFrequency:'yearly',priority:.2},{url:`${base}/cart`,changeFrequency:'weekly',priority:.2},...products.filter(p=>p.active&&p.slug).map(p=>({url:`${base}/products/${p.slug}`,lastModified:p.updatedAt?new Date(p.updatedAt):new Date(),changeFrequency:'weekly' as const,priority:.8}))]}

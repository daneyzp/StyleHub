import type { MetadataRoute } from 'next';
export default function robots():MetadataRoute.Robots{const base=(process.env.NEXT_PUBLIC_SITE_URL||'https://yourstore.com').replace(/\/$/,'');return {rules:[{userAgent:'*',allow:'/',disallow:['/api/','/portal/','/account','/checkout','/cart','/wishlist','/login']}],sitemap:`${base}/sitemap.xml`,host:base}}

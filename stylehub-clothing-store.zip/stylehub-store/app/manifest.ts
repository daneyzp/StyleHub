import type { MetadataRoute } from 'next';
export default function manifest():MetadataRoute.Manifest{return {name:'StyleHub Clothing Store',short_name:'StyleHub',description:'Thoughtful everyday fashion',start_url:'/',display:'standalone',background_color:'#ffffff',theme_color:'#171916',icons:[]}}

import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';
export const metadata: Metadata = { metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://yourstore.com'), title: { default: 'StyleHub — Thoughtful Everyday Fashion', template: '%s | StyleHub' }, description: 'Discover considered clothing, modern essentials and everyday style at StyleHub.', robots: { index: true, follow: true } };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en-IN"><body><Header/>{children}<footer className="footer"><div><div className="brand">Style<span>Hub</span></div><small>Thoughtful everyday fashion. Made to be worn on repeat.</small></div><div className="inline"><a href="/account">My account</a><a href="/wishlist">Wishlist</a><a href="/cart">Cart</a></div><small>© {new Date().getFullYear()} StyleHub · India</small></footer></body></html>}

'use client';
import { useEffect,useState } from 'react';
import Link from 'next/link';
import { onAuthStateChanged, signOut, type User } from 'firebase/auth';
import { auth } from '@/lib/firebase';
export default function AccountPage(){const [user,setUser]=useState<User|null>(null);const [ready,setReady]=useState(false);useEffect(()=>{if(!auth){setReady(true);return;}return onAuthStateChanged(auth,u=>{setUser(u);setReady(true)})},[]);return <main className="page"><p className="eyebrow">YOUR STYLEHUB</p><h1>My account</h1>{!ready?<p>Loading account…</p>:user?<><p className="pageLead">Welcome back, {user.displayName||user.email}.</p><div className="inline"><Link className="button" href="/wishlist">Wishlist</Link><Link className="button outline" href="/cart">Shopping bag</Link><button className="button outline" onClick={()=>signOut(auth!)}>Sign out</button></div><div className="notice">Order history will appear here after the secure order API and payment provider are configured.</div></>:<><p className="pageLead">Sign in to manage your account and shopping bag.</p><Link className="button" href="/login">Sign in / Register</Link></>}</main>}

import Link from 'next/link';
export default function NotFound(){return <main className="page"><p className="eyebrow">404 · NOT FOUND</p><h1>This piece is out of sight.</h1><p className="pageLead">The page may have moved or the product may no longer be available.</p><Link className="button" href="/">Return to StyleHub</Link></main>}
